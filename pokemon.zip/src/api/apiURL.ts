export const APIURL = {
  POKEMON_URL: 'https://pokeapi.co/api/v2/',
  AUTH_URL: 'https://cafe-admin-api-production.up.railway.app/',
}