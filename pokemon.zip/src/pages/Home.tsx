export const Home = () => {
  console.log('Home component rendered');
  return <div>Home</div>;
}